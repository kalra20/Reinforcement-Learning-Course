import gym
import tqdm
import torch
import argparse
import numpy as np
import scipy.io as io
import torch.nn as nn
import torch.optim as optim
from torch import autograd
from functools import partial
import matplotlib.pyplot as plt
import torch.nn.functional as F
from torch.autograd import Variable
from torch.distributions.kl import kl_divergence
from torch.distributions import Categorical, Normal
from torch.nn.utils import parameters_to_vector, vector_to_parameters




parser = argparse.ArgumentParser()

parser.add_argument("--env", default="CartPole-v0",
                    help="CartPole-v0 / Pendulum-v0")
parser.add_argument("--mode", default="train",
                    help="Train or Test mode")

parser.add_argument("--algorithm", default="VanillaPG",
                    help="VanillaPG / VPG_baseline / ActorCritic")

parser.add_argument("--batch_size", default=2048,
                    help="batch size (in steps)")

parser.add_argument("--num_steps", default=10000000,
                    help="Max number of steps to train")








class Policy(nn.Module):
    def __init__(self, input_dim, output_dim, discrete=True, gaussian=False, layer_size=32):
        super().__init__()
        self.fc1 = nn.Linear(input_dim, layer_size)
        self.fc2 = nn.Linear(layer_size, layer_size)
        self.fc3 = nn.Linear(layer_size, output_dim)
        self.fc4 = nn.Linear(layer_size, output_dim)

        self.discrete = discrete
        self.gaussian = gaussian
        if not self.gaussian:
            self.log_std = nn.Parameter(torch.Tensor([[0.]]))
        self.activation = nn.Tanh()
        self.sigmoid = nn.Sigmoid()

    def forward(self, state):
        x = self.activation(self.fc1(state))
        x = self.activation(self.fc2(x))
        mu = self.fc3(x)

        if self.discrete:
            mu = F.softmax(mu, dim=1)

        if self.gaussian:
            self.log_std = self.sigmoid(self.fc4(x))

        return mu



class Critic(nn.Module):
    def __init__(self, input_dim, layer_size=32):
        super().__init__()
        self.fc1 = nn.Linear(input_dim, layer_size)
        self.fc2 = nn.Linear(layer_size, layer_size)
        self.fc3 = nn.Linear(layer_size, 1)

        self.activation = nn.Tanh()
        self.softmax = nn.Softmax()

    def forward(self, state):

        x = self.activation(self.fc1(state))
        x = self.activation(self.fc2(x))
        x = self.fc3(x)

        return x

class PolicyGradient:

    def __init__(self, env='Pendulum-v0', trpo=False, ppo=False, actorcritic=False, vanilla=True, baseline=False, gaussian=False, max_steps=10000000, batch_size=2048,
                 learning_rate=0.001, entropy_weight=0.2, gamma=0.99, trace_decay=0.97, eps = 1e-8, num_cg = 10, damping_coeff=0.1, kl_thresh=0.05, layer_size=32, 
                 ppo_steps=20, ppo_clip=0.2, log_file="./actor_critic.mat"):
        super().__init__()
        self.eps = eps
        self.actorcritic = actorcritic
        self.vanilla = vanilla
        self.baseline = baseline
        self.gaussian = gaussian
        self.trpo = trpo
        self.ppo = ppo
        self.env = gym.make(env)

        if str(self.env.action_space)[:-3] == "Discrete":
            self.discrete = True
            out_dim = self.env.action_space.n
        else:
            self.discrete = False
            out_dim = self.env.action_space.shape[0]

        self.policy = Policy(self.env.observation_space.shape[0], out_dim, self.discrete, self.gaussian, layer_size)
        self.critic = Critic(self.env.observation_space.shape[0], layer_size)
        self.gamma = gamma


        self.log = {}
        self.log_file = log_file
        self.batch_size = batch_size
        self.max_steps = max_steps
        self.trace_decay = trace_decay
        self.learning_rate = learning_rate
        self.entropy_weight = entropy_weight
        self.actor_checkpoint = "./actor_" + env + ".pth"
        self.critic_checkpoint = "./critic_" + env + ".pth"
        self.actor_optim = optim.Adam(self.policy.parameters(), lr=learning_rate)
        if not vanilla:
            self.critic_optim = optim.Adam(self.critic.parameters(), lr=learning_rate)

        if self.trpo:
            self.num_cg = num_cg
            self.damping_coeff = damping_coeff
            self.kl_thresh = kl_thresh
            self.backtrack_coeff = 0.8
            self.num_backtrack = 10

        if self.ppo:
            self.ppo_clip = ppo_clip
            self.ppo_steps = ppo_steps





    def hessian_vector_product(self, d_kl, x):
        '''
         
        Borrowed from openai baseline code
        https://github.com/openai/baselines/blob/master/baselines/common/cg.py
         '''
        g = parameters_to_vector(autograd.grad(d_kl, self.policy.parameters(), create_graph=True))
        return parameters_to_vector(autograd.grad((g * x.detach()).sum(), self.policy.parameters(), retain_graph=True)) + self.damping_coeff * x



    def conjugate_gradient(self, Ax, b):
        '''
         
        Borrowed from openai baseline code
        https://github.com/openai/baselines/blob/master/baselines/common/cg.py
         '''
        x = torch.zeros_like(b)
        r = b - Ax(x)  # Residual
        p = r  # Conjugate vector
        r_dot_old = torch.dot(r, r)
        for _ in range(self.num_cg):  # Run for a limited number of steps
            Ap = Ax(p)
            alpha = r_dot_old / (torch.dot(p, Ap) + 1e-8)
            x += alpha * p
            r -= alpha * Ap
            r_dot_new = torch.dot(r, r)
            p = r + (r_dot_new / r_dot_old) * p
            r_dot_old = r_dot_new
        return x

    def update(self, batch_data):

        for data in batch_data:
            data["V_s"] = self.critic(data["state"]).squeeze(1)
            #data["V_ns"] = self.critic(data["next_state"]).squeeze(1)

        with torch.no_grad():
            return_s = torch.zeros(1); advantage =torch.zeros(1); V_ns = torch.zeros(1);
            for data in reversed(batch_data):
                return_s = data["reward"] + ((1 - data["done"])*self.gamma*return_s)
                #V_s, V_ns = self.critic(data["state"]), self.critic(data["next_state"])
                td_error = (data["reward"] + (1 - data["done"])*self.gamma*V_ns) - data["V_s"]
                # Advantage is an expectation of td_error (treating Value function V(s) as baseline
                advantage = td_error + ((1 - data["done"])*self.gamma*self.trace_decay*advantage)
                data["Advantage"] = advantage
                data["G_s"] = return_s
                V_ns = data["V_s"]
        batch_data = {key: torch.cat([data[key] for data in batch_data], 0) for key in batch_data[0].keys()}

        if self.baseline and self.actorcritic:
            batch_data["Advantage"] = (batch_data["Advantage"] - batch_data["Advantage"].mean()) / (batch_data["Advantage"].std() + self.eps)

        if self.baseline and self.vanilla:
            batch_data["G_s"] = (batch_data["G_s"] - batch_data["G_s"].mean()) / (batch_data["G_s"].std() + self.eps)


        # if (batch_data["Advantage"].size()) < 2:
        #     batch_data["Advantage"] = batch_data["Advantage"].squeeze(1)
        if len(batch_data["log_prob"].size()) < 2:
            batch_data["log_prob"] = batch_data["log_prob"].unsqueeze(1)

        if self.actorcritic:
            aloss = -1 * (batch_data["Advantage"] * batch_data["log_prob"].sum(1)).mean()
        elif self.vanilla:
            aloss = -1 * (batch_data["G_s"] * batch_data["log_prob"].sum(1)).mean()

        self.actor_optim.zero_grad()
        aloss.backward()
        self.actor_optim.step()

        if not self.vanilla:
            closs = (batch_data["V_s"] - batch_data["G_s"]).pow(2).mean()
            self.critic_optim.zero_grad()
            closs.backward()
            self.critic_optim.step()


    def update_trpo(self, batch_data):

        for data in batch_data:
            data["V_s"] = self.critic(data["state"]).squeeze(1)
            #data["V_ns"] = self.critic(data["next_state"]).squeeze(1)

        with torch.no_grad():
            return_s = torch.zeros(1); advantage =torch.zeros(1); V_ns = torch.zeros(1);
            for data in reversed(batch_data):
                return_s = data["reward"] + ((1 - data["done"])*self.gamma*return_s)
                #V_s, V_ns = self.critic(data["state"]), self.critic(data["next_state"])
                td_error = (data["reward"] + (1 - data["done"])*self.gamma*V_ns) - data["V_s"]
                # Advantage is an expectation of td_error (treating Value function V(s) as baseline
                advantage = td_error + ((1 - data["done"])*self.gamma*self.trace_decay*advantage)
                data["Advantage"] = advantage
                data["G_s"] = return_s
                V_ns = data["V_s"]
        batch_data = {key: torch.cat([data[key] for data in batch_data], 0) for key in batch_data[0].keys()}
        batch_data["Advantage"] = (batch_data["Advantage"] - batch_data["Advantage"].mean()) / (batch_data["Advantage"].std() + self.eps)

        pi = Normal(self.policy(batch_data["state"]), self.policy.log_std.exp())
        pi_old = Normal(batch_data["pi_old_mean"], batch_data["pi_old_std"]) 

        IS_ratio = (pi.log_prob(batch_data["action"]).sum(1) - batch_data["pi_old_log_prob"].sum(1)).exp() #pi_old.log_prob(batch_data["action"]) )
        aloss = -1 * (IS_ratio * batch_data["Advantage"]).mean()

        grad_pi = parameters_to_vector(autograd.grad(aloss, self.policy.parameters(), allow_unused=True, retain_graph=True))

        kl_distance = kl_divergence(pi, pi_old).sum(dim=1).mean()
        Hx = partial(self.hessian_vector_product, kl_distance)
        x = self.conjugate_gradient(Hx, grad_pi)

        #Backtracking Line Search

        epsilon = torch.sqrt((2 * self.kl_thresh) /(torch.dot(x, Hx(x)) + self.eps)).item()
        pi_old_loss = aloss.item()
        pi_old_params = parameters_to_vector(self.policy.parameters()).detach()

        with torch.no_grad():
            for iteration in range(self.num_backtrack):
                step_size = (self.backtrack_coeff**iteration) * epsilon
                vector_to_parameters(pi_old_params - step_size*x, self.policy.parameters())
                pi = Normal(self.policy(batch_data["state"]), self.policy.log_std.exp())
                pi_old = Normal(batch_data["pi_old_mean"], batch_data["pi_old_std"]) 

                IS_ratio = (pi.log_prob(batch_data["action"]).sum(1) - batch_data["pi_old_log_prob"].sum(1)).exp() #pi_old.log_prob(batch_data["action"]) )
                aloss = -1 * (IS_ratio * batch_data["Advantage"]).mean()
                kl_distance = kl_divergence(pi, pi_old).sum(dim=1).mean().item()

                if (aloss <= pi_old_loss) and (kl_distance <= self.kl_thresh):
                    break
                elif iteration == self.num_backtrack-1:
                    vector_to_parameters(pi_old_params, self.policy.parameters())
                else:
                    pass

        closs = (batch_data["V_s"] - batch_data["G_s"]).pow(2).mean()
        self.critic_optim.zero_grad()
        closs.backward()
        self.critic_optim.step()

    def update_ppo(self, batch_data):

        for data in batch_data:
            data["V_s"] = self.critic(data["state"]).squeeze(1)
            #data["V_ns"] = self.critic(data["next_state"]).squeeze(1)

        with torch.no_grad():
            return_s = torch.zeros(1); advantage =torch.zeros(1); V_ns = torch.zeros(1);
            for data in reversed(batch_data):
                return_s = data["reward"] + ((1 - data["done"])*self.gamma*return_s)
                #V_s, V_ns = self.critic(data["state"]), self.critic(data["next_state"])
                td_error = (data["reward"] + (1 - data["done"])*self.gamma*V_ns) - data["V_s"]
                # Advantage is an expectation of td_error (treating Value function V(s) as baseline
                advantage = td_error + ((1 - data["done"])*self.gamma*self.trace_decay*advantage)
                data["Advantage"] = advantage
                data["G_s"] = return_s
                V_ns = data["V_s"]
        batch_data = {key: torch.cat([data[key] for data in batch_data], 0) for key in batch_data[0].keys()}
        batch_data["Advantage"] = (batch_data["Advantage"] - batch_data["Advantage"].mean()) / (batch_data["Advantage"].std() + self.eps)


        for step in range(self.ppo_steps):
            batch_data["V_s"] = self.critic(batch_data["state"])
            pi = Normal(self.policy(batch_data["state"]), self.policy.log_std.exp())
            IS_ratio = (pi.log_prob(batch_data["action"]).sum(1) - batch_data["pi_old_log_prob"].sum(1)).exp()
            aloss = -1 * (batch_data["Advantage"] * torch.min(IS_ratio, torch.clamp(IS_ratio, 1 - self.ppo_clip, 1 + self.ppo_clip))).mean()

            self.actor_optim.zero_grad()
            aloss.backward()
            self.actor_optim.step()

            closs = (batch_data["V_s"] - batch_data["G_s"]).pow(2).mean()
            self.critic_optim.zero_grad()
            closs.backward()
            self.critic_optim.step()

    def train(self):

        steps = []
        total_rewards = []
        total_avg_reward = []
        state, done = self.env.reset(), False
        total_reward = 0
        episode = 0

        batch_data = []
        episodes = []
        episode_rewards = []
        tqdm_bar = tqdm.tqdm(range(1, self.max_steps+1), unit_scale=1, smoothing=0)
        for step in tqdm_bar:
            
            state = torch.from_numpy(state)
            state = state.unsqueeze(0).float()
            if self.discrete:
                policy = Categorical(self.policy(state))
            else:
                policy = Normal(self.policy(state), self.policy.log_std.exp())
            action = policy.sample()

            log_prob = policy.log_prob(action)
            ns, reward, done, _ = self.env.step(action[0].detach().numpy())
            total_reward += reward

            state_tuple = {}
            state_tuple["done"] = torch.tensor([done], dtype=torch.float32)
            state_tuple["state"] = state
            state_tuple["action"] = action
            state_tuple["next_state"] = torch.from_numpy(ns).unsqueeze(0).float()
            state_tuple["reward"] = torch.tensor([reward])
            state_tuple["log_prob"] = log_prob
            state_tuple["pi_old_mean"] = policy.loc.detach()
            state_tuple["pi_old_std"] = policy.scale.detach()
            state_tuple["pi_old_log_prob"] = log_prob.detach()
            state = ns
            batch_data.append(state_tuple)
            if done:
                tqdm_bar.set_description("Episode: %d | Reward: %f" % (episode, total_reward))
                episodes.append(episode)
                episode_rewards.append(total_reward)
                total_reward = 0
                episode += 1

                state, done = self.env.reset(), 0

                if len(batch_data) > self.batch_size:
                    if self.trpo:
                        self.update_trpo(batch_data)
                    elif self.ppo:
                        self.update_ppo(batch_data)
                    else:
                        self.update(batch_data)
                    # with torch.no_grad():
                    # Save log file
                    self.log["Episodes"] = episodes
                    self.log["Reward per Episode"] = episode_rewards
                    io.savemat(self.log_file, self.log)

                    # Save model checkpoint
                    torch.save(self.policy.state_dict(), self.actor_checkpoint)
                    torch.save(self.critic.state_dict(), self.critic_checkpoint)

                    batch_data = []

if __name__ == "__main__":
    args = parser.parse_args()
    pg = PolicyGradient(env=args.env, actorcritic=True, baseline=True, gaussian=True, log_file=args.env+".mat")
    pg.train()




